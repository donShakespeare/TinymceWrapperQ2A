#TinymceWrapper (aka Miranda the beautiful)
Special edition for the awesome 
[Question2Answer community](http://www.question2answer.org/qa/51849/tinymcewrapper-miranda-updated-most-powerful-editor-joins-q2a)

##DEMO: [Check it out here](http://www.leofec.com/demo/question2answer/7/features-tinymcwrapper-rt-md-editor-for-question2answer)

>I shall give them a tool whereby to write. This tool shall make them laugh. And when they shall have written, their content shall please both them that did the composition and them that shall chance to read or hear of said content.
> **-- _donshakespeare to Kalif the Grateful_**

<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RAMXZQZQD2NKA" target="_blank"><img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" alt="Donate via PayPal - The safer, easier way to pay online!"></a>
